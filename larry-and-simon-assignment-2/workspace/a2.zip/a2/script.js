function updateFlexibility (val){
    var flex = ["Inflexible", "Flexible", "Super-Flexible"];
    document.getElementById("output").innerHTML = flex[val];
}